=== IN Europe ===
Contributors: veedoo
Tags: eu, europe, britain
Requires at least: 3.0.1
Tested up to: 4.3
Stable tag: 4.3
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Show your support for British membership of the EU

== Description ==

Install and configure our plugin to send a clear and powerful message to your webite visitors: we want Britain in the EU

*   Customise the banner and text colours
*   Choose from five different UK/EU icons.
*   Select from different support messages
*   Customise the banner link URL

    We developed this plugin to encourage pro-European businesses and website owners to show their support for British membership of the EU. Too much is at stake to remain silent and risk jeapordising our relationship with our most important allies.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/plug-in-europe` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. Use the Dashboard->European Banner screen to configure the plugin


== Changelog ==

= 0.2.1 =
* Proeuropa campaign has bee added

= 0.2.0 =
* Now you can choose between several campaigns
* Liberal Democrats campaign has bee added

= 0.1.6 =
* Security fixes

= 0.1.5 =
* First public release

== Upgrade Notice ==

= 0.2.1 =
* Update to be have more campaigns.

= 0.2.0 =
* Update to be able to choose campaigns.

= 0.1.6 =
* Update your plugin for important security fixes.

= 0.1.5 =
* Support Britain IN Europe!